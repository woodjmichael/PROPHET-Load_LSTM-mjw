import pandas as pd
from datetime import datetime
from pickle import dump
from PROPHET_LOAD_LSTM.util import util
from PROPHET_LOAD_LSTM.util.data_util import prepare_data_train
from PROPHET_LOAD_LSTM.util.model_util import create_model_attention

from PROPHET_DB import mysql

# import daiquiri
# import sklearn.preprocessing

# from PROPHET_DB.setup_logger import setup_logger

# Logger definition
# LOGGER = daiquiri.getLogger(__name__)


def main(argv=None):
    # read configuration file
    args = util.parse_arguments(argv)

    config = util.read_config(args.config)
    data_opt = {
        'n_back': 96*3,#config.getint("data_opt", "n_back"),  # 4*24*7
        'n_timesteps': int(1.5*96),# config.getint("data_opt", "n_timesteps"),  # 4*4
        'lag': 0,#config.getint("data_opt", "lag"),
        'tr_per': 0.90,#config.getfloat("data_opt", "tr_per"),
        'out_col': ['power'],#config.get("data_opt", "out_col").split(','),
        'features': [],#config.get("data_opt", "features").split(','),
        'freq': config.getint("data_opt", "freq"),
        'tr_days_step': config.getint("data_opt", "tr_days_step"),
    }
    data_opt['columns'] = data_opt['features'] + data_opt['out_col']
    data_opt['n_features'] = len(data_opt['columns'])

    model_opt = {'Dense_input_dim': 24,#config.getint("model_opt", "Dense_input_dim"),
                 'LSTM_num_hidden_units': [24],#list(map(int, config.get("model_opt", "LSTM_num_hidden_units").split(','))),
                 'LSTM_layers': 1,#config.getint("model_opt", "LSTM_layers"),
                 'metrics': 'mse',#config.get("model_opt", "metrics"), 'optimizer': config.get("model_opt", "optimizer"),
                 'patience': 5,#config.getint("model_opt", "patience"), 'epochs': config.getint("model_opt", "epochs"),
                 'validation_split': 0.2,#config.getfloat("model_opt", "validation_split"),
                 'model_path': 'D:\GitHub\PROPHET-Load_LSTM\PROPHET_LOAD_LSTM\models',#config.get("model_opt", "model_path"),
                 'Dropout_rate': 0.2,#config.getfloat("model_opt", "Dropout_rate"),
                 'input_dim': 288,#(data_opt['n_back'], data_opt['n_features']), 'dense_out': data_opt['n_timesteps']}
                 'optimizer':'Adam',
                 'epochs':50,
                 }
    # logger_config = {'mailhost': (config["logger"]["mailhost"], config.getint("logger", "port")),
    #                  'fromaddr': config["logger"]["fromaddr"],
    #                  'toaddr': config["logger"]["toaddrs"],
    #                  'subject': config["logger"]["subject"],
    #                  'credentials': (config["logger"]["username"], config["logger"]["password"]),
    #                  'mail_handler': config.getboolean("logger", "mail_handler"),
    #                  'backup_count': config.getint("logger", "backup_count")}

    #
    talktoSQL = mysql.MySQLConnector(database=config["mysql"]["database"],
                                     host=config["mysql"]["host"],
                                     port=config["mysql"]["port"],
                                     user=config["mysql"]["user"],
                                     password=config["mysql"]["password"])

    # (talktoSQL, table_mysql, column_mysql, time_column)
    # ev_query = util.create_query(talktoSQL, config["tables"]["measures"], config["columns"]["measures"], config["tables"]["time_column"])
    # ev_query = ev_query + 'order by TimeCol desc limit 1000'
    # df = talktoSQL.read_query(ev_query, {config["tables"]["time_column"]})
    # df[config["tables"]["time_column"]] = pd.to_datetime(df[config["tables"]["time_column"]], format='%Y-%m-%d %H:%M:%S%z')#.dt.tz_convert('America/Los_Angeles')
    #
    # df.rename(columns={config["columns"]["measures"]: 'power'}, inplace=True)
    # df.set_index(config["tables"]["time_column"], inplace=True)

    #df.to_csv('C:\\Users\\PROPHET\\Desktop\\Mike\\test.csv')

    df = pd.read_csv("C:\\Users\\PROPHET\\Documents\\Mike\\train_JPL_5_mjw.csv", sep=",")
    df[config["tables"]["time_column"]] = pd.to_datetime(df['timestamp_utc'], format='%d/%m/%Y %H:%M')
    df.set_index(config["tables"]["time_column"], inplace=True)

    df['year'] = df.index.year
    df['month'] = df.index.month
    df['day'] = df.index.dayofweek
    df['hour'] = df.index.hour
    df['minute'] = df.index.minute
    df = df[data_opt['columns']]

    ## definizione tempi inizio
    now = datetime.utcnow()
    fine_tr = pd.to_datetime(now)#.tz_localize('UTC')  ## METTERE A POSTO MA SECONDARIO

    mask_tr = (df.index < fine_tr)
    train = df.loc[mask_tr]

    #### addestra il modello
    train_X, train_y, scaler_X, scaler_y = prepare_data_train(train, data_opt)
    train_y = train_y.reshape((train_y.shape[0], train_y.shape[1], 1))

    dump(scaler_X, open(model_opt["model_path"] + "scaler_in.pkl", 'wb'))
    dump(scaler_y, open(model_opt["model_path"] + "scaler_out.pkl", 'wb'))

    model, history = create_model_attention(model_opt, train_X, train_y)

if __name__ == "__main__":
    main()